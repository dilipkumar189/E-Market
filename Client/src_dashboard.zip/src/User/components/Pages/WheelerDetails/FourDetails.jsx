import React from 'react'

export default function FourDetails() {
  return (
    <>
        <h1>Four Wheeler Details</h1>
    </>      
  )
}
