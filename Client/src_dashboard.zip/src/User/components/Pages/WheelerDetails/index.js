import FourDetails from "./FourDetails";
import ThreeDetails from "./ThreeDetails";
import TwoDetails from "./TwoDetails";

export {
    FourDetails,
    ThreeDetails,
    TwoDetails,
}