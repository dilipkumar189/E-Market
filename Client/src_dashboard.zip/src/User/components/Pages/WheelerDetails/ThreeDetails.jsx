import React from 'react'

export default function ThreeDetails() {
  return (
    <>
        <h1>Three Wheeler Details</h1>
    </>
  )
}
