import React from 'react'

export function Contact() {
  return (
    <>
        <h4>Contact page</h4>
    </>
  )
}
