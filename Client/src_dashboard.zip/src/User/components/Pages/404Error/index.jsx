import React from 'react'

export function Error404() {
  return (
    <>
        <h4>404 Error</h4>
        <p>Page does not found!</p>
        <p>Try Again</p>
    </>
  )
}
