import React from 'react'

export function About() {
  return (
    <>
        <h4>About page</h4>
    </>
  )
}
