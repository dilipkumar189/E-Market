import logo from "./logo.png"
import cowork01 from "./cowork-01.png"
import cowork02 from "./cowork-02.png";
import cowork03 from "./cowork-03.png";

export {
    logo, cowork01, cowork02, cowork03
}